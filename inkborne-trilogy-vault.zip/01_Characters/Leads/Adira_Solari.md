---
title: Adira Solari
type: character
category: lead_fmc
status: confirmed_canon
aliases:
  - Adira
  - Adira of Clan Solari
  - Adira te Solari
  - The Unmarked Bride
  - Master Wayfinder
tags:
  - character/lead
  - faction/sun_gilded_isles
  - faction/clan_solari
  - magic/unmarked_canvas
---

# Adira Solari (Master Wayfinder)

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                        ADIRA SOLARI (AGE 23)                                         ║
╠══════════════════════════════════════════════════════════════════════════════════════════════════════╣
║ • Height & Build: 5'8" (173 cm) • Lithe, powerful, athletic free-diver physique.                     ║
║ • Complexion: Luminous golden-bronze skin • Smooth, completely unmarked canvas (zero ink).           ║
║ • Facial Structure: Striking, elegant features • High cheekbones • Expressive, brave gaze.          ║
║ • Hair: Sunlit Cocoa • Waist-length dark chocolate/espresso brown with loose waves & sun-kissed      ║
║   golden-copper highlights; braided with mother-of-pearl or pinned with carved whalebone.            ║
║ • Eyes: Warm Topaz Amber • Luminous golden-amber eyes; intensely observant and impossible to deceive.║
║ • Posture: Graceful, grounded ocean poise • Fluid aquatic reflexes • Exceptional cold stamina.       ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝
```

---

## 0. Canonical Identity & Titles

* **Full Mainland Legal Name:** **Adira Solari**
* **Homeland Lineage Title:** **Adira of Clan Solari** (*Adira te Solari*)
* **The Clan Name Rule (Model 2 Confirmed):**
  * On [[03_Worldbuilding/The_Sun_Gilded_Isles/The_Five_Isles_and_Clans|The Sun-Gilded Isles]], clan names (*Solari*) are exclusive honorifics held solely by the **hereditary Clan Leaders and their direct bloodline**.
  * Common civilians go by single names or craft titles. Mainlanders record her on legal registries as **Adira Solari**.
* **Titles & Ranks:** 
  * Master Wayfinder of [[03_Worldbuilding/The_Sun_Gilded_Isles/The_Five_Isles_and_Clans|Isle of Solara]]
  * Daughter of the High Clan Leader of Solara
  * Guardian of [[03_Worldbuilding/The_Sun_Gilded_Isles/Mount_Kora_and_Mountain_Blood|Mount Kora's Secret]]

---

## 1. Heritage, Origin & The Mother's Locket

* **Origin:** The **Isle of Solara**, the celestial navigation center of the Sun-Gilded Isles.
* **The Mother's Locket:**
  * A hermetically sealed teardrop pendant of translucent black volcanic obsidian framed in polished mother-of-pearl.
  * Holds a single, pure droplet of raw subterranean **Prime Ink** (*"Mountain Blood"*).
  * Given by her late mother with the ancestral warning: *"Never open it, never spill it, and never speak of what lies inside. If you are lost across uncharted seas, this drop will guide you home."*

---

## 2. Signature Skills & Unique Abilities

* **Master Wayfinder & Celestial Tracker:**
  * Memorized the oral epic *Song of the Star Compass*. Reads barometric shifts, ocean swells, wave reflection pulses, and cloud formations by intuition and touch.
* **The Observational Genius (The Only Reader of His Ink):**
  * Her extreme wayfinding sensitivity makes her the **only person on the continent who reads [[01_Characters/Leads/Kyrell_Mavaros|Kyrell]]'s ink micro-tells**—she spots the momentary shadow-flicker on his collarbone, throat, or wrist when his emotions flare.
* **Athletic Free-Diver:**
  * 4+ minute breath capacity; zero panic when submerged; high endurance in freezing water.
* **Obsidian Precision:**
  * Master of twin obsidian daggers, holding microscopic edges sharper than continental steel.

---

## 3. Weapons & Signature Equipment

* **Twin Hand-Carved Obsidian Daggers:** Razor-sharp volcanic black glass with carved whalebone hilts.
* **Composite Recurve Shortbow:** Horn-and-wood shortbow crafted for fast, agile defense.
* **The Mother's Locket:** Sealed obsidian and mother-of-pearl talisman.

---

## 4. Personality, Interiority & Romance Dynamics

* **Personality Archetype:** Brave, observant, fiercely independent, compassionate, and unwavering in loyalty.
* **The Core Lie:** *"My life and freedom belong to my people; my duty is to be a sacrificial political pawn to keep our islands hidden and peaceful."*
* **The Conscious Want:** To survive the mainland, protect Mount Kora's secret from imperial greed, and sail home with [[01_Characters/Allies/Ronan|Ronan]].
* **The Subconscious Need:** To accept that she deserves a life, a choice, and a passionate love of her own—not just an arranged political sacrifice to [[01_Characters/Antagonists/Theron_Clan_Korvos|Theron]].
* **Romance Dynamics with [[01_Characters/Leads/Kyrell_Mavaros|Kyrell Mavaros]]:**
  * Mutual competence and intellectual parity from the first collision.
  * She strips away his emotional armor without realizing it; she is one of the only living souls who calls him *Kyrell*.
