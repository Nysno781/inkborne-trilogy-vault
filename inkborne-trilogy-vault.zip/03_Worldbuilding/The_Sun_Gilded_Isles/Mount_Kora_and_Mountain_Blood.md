---
title: Mount Kora, Mountain Blood and The Mother's Locket
type: lore
category: worldbuilding
status: confirmed_canon
tags:
  - worldbuilding
  - sun_gilded_isles
  - magic_origin
  - prime_ink
---

# Mount Kora & The Caldera Taboo

---

## 1. Mount Kora (The Slumbering Heart)
* **The Sacred Caldera:** The central active volcano of the Sun-Gilded Isles, revered as the living heart of their ancestors.
* **The Untapped Reservoir:** Deep beneath Mount Kora lies a massive, untouched subterranean lake of pure **Prime Ink**, known to islanders as **"Mountain Blood"**.
* **The Sacred Taboo:** Ancient spiritual law strictly forbids ever harvesting, bottling, or weaponizing the black liquid. To use it for war is the ultimate sacrilege.
* **The Existential Threat:** Her people possess zero tattoo magic or military weapons; if the Valerian Empire ever discovers the archipelago, it will launch an invasion armada to strip-mine Mount Kora.

---

## 2. The Mother's Locket (The Sacred Calamity Talisman)

* **The Pendant:** A hermetically sealed teardrop pendant carved from translucent black volcanic obsidian, framed in polished mother-of-pearl and hung from a braided sea-grass cord.
* **What Lies Inside:** A single, pure, unadulterated droplet of raw subterranean Prime Ink (*Mountain Blood*).
* **Origin:** [[01_Characters/Leads/Adira_Solari|Adira Solari]]'s late mother secretly harvested the drop from a fissure near Mount Kora's rim before her death, passing it down with the ancestral warning:
  > *"The Mountain Blood must never be used for war. But if the world ever falls into ruin and you are lost across uncharted seas, this drop is the living pulse of our mountain. It will guide you home."*
* **Secrecy:** Only Adira and her late mother know what is inside. To the rest of the world, it appears as an ancestral mourning keepsake.
